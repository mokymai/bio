<!-- document begins: DO NOT REMOVE THIS LINE -->


# Repository of R packages

This repository contains the following *R* packages:

<!-- current versions: start -->

- **addins.html** 0.0.3
- **addins.icon** 0.0.2
- **addins.rmd** 0.0.10
- **addins.rs** 0.0.9
- **addin.tools** 0.0.9
- **backup.tools** 0.0.1
- **bio** 0.0.6
- **RcmdrPlugin.biostat** 0.0.68
- **snippets** 0.0.4

<!-- current versions: end -->


These archived (old) versions of the packages are also available:

<!-- archived versions: start -->

- **bio** 0.0.5.3

<!-- archived versions: end -->


# How to download a package from this repository?

To download these packages, you can use the same functions you use to download 
or update packages form [CRAN](https://www.r-project.org/). The only difference
is that you should provide additional repository
**https://mokymai.github.io/download/**.

An example of R code to download package **bio**:

```r
repos <- c("https://mokymai.github.io/download/", getOption("repos"))
install.packages("bio", repos = repos)
```


<!-- end of document: DO NOT REMOVE THIS LINE-->
